# 🤖 Aura AI — Free Universal AI for Everyone

Aura AI is a feature-packed, modern AI web application designed to run completely free for you and your users.

---

## 🌟 Key Features

1. **Multiple Free AI Models**:
   - **Qwen 2.5 7B (OpenRouter Free)**: High intelligence, great at coding & general logic.
   - **Gemma 2 9B (OpenRouter Free)**: Google open-weight reasoning model.
   - **DeepSeek R1 (OpenRouter Free)**: Open reasoning model.
   - **Groq Llama 3.3 70B**: Ultra-fast inference with free Groq API keys.
   - **Local Smart Engine**: Zero network requirements, 100% offline-compatible client-side generator.

2. **5 Built-In AI Personas**:
   - 🌟 Universal Assistant
   - 💻 Code Master & Architect
   - 📝 Creative Writer
   - 🎓 Patient Educator
   - ⚡ Quick & Direct Q&A

3. **Rich Interactive Features**:
   - 💬 **Streaming Text**: Real-time word-by-word typing responses.
   - 🎨 **Markdown Formatting**: Code syntax highlighting, tables, blockquotes, lists.
   - 📋 **One-Click Code Copy**: Copy code snippets effortlessly.
   - 🔊 **Text-To-Speech**: Listen to responses spoken aloud.
   - 🎤 **Voice Input**: Speak your prompt directly with browser speech recognition.
   - 💾 **Local Storage Persistence**: Sessions and history saved securely in your browser.
   - 📥 **Export Chat**: Download chat history as Markdown files.
   - ⚙️ **Settings Modal**: Temperature control, token limiters, API key management.

---

## 🚀 How to Deploy to Vercel / Netlify / Cloudflare (100% Free)

### Option 1: Vercel (Recommended - 1 Click)
1. Push this folder to a free **GitHub Repository**.
2. Go to [Vercel.com](https://vercel.com) -> New Project.
3. Import your GitHub repo and click **Deploy**.
4. In ~30 seconds your app will be live on a free `.vercel.app` domain!

### Option 2: Netlify or Cloudflare Pages
1. Run `npm run build`.
2. Drag and drop the generated `dist/` folder into Netlify or Cloudflare Pages.

---

## 🛠️ Tech Stack
- **Framework:** React 19 + TypeScript + Vite 8
- **Styling:** Tailwind CSS v4 + Dark Glassmorphism UI
- **Icons:** Lucide React
- **Markdown & Code:** Marked
- **Effects:** Canvas Confetti
