import type { AIModel, SystemPersona } from '../types';

export const DEFAULT_MODELS: AIModel[] = [
  {
    id: 'openrouter/qwen-2.5-7b',
    name: 'Qwen 2.5 7B (Free)',
    provider: 'OpenRouter Free',
    description: 'High intelligence open model, excellent at coding and general questions.',
    badge: '100% Free',
    isFreeByDefault: true,
    requiresKey: false,
    speed: 'Fast',
  },
  {
    id: 'openrouter/gemma-2-9b',
    name: 'Gemma 2 9B (Free)',
    provider: 'OpenRouter Free',
    description: 'Google open weight model with strong reasoning capabilities.',
    badge: '100% Free',
    isFreeByDefault: true,
    requiresKey: false,
    speed: 'Fast',
  },
  {
    id: 'openrouter/deepseek-r1',
    name: 'DeepSeek R1 (Free)',
    provider: 'OpenRouter Free',
    description: 'Advanced open reasoning model for complex problem solving.',
    badge: 'Reasoning AI',
    isFreeByDefault: true,
    requiresKey: false,
    speed: 'Moderate',
  },
  {
    id: 'groq/llama-3.3-70b',
    name: 'Llama 3.3 70B (Groq Fast)',
    provider: 'Groq',
    description: 'Lightning fast 70B parameter model via Groq free tier API key.',
    badge: 'Ultra Fast',
    isFreeByDefault: false,
    requiresKey: true,
    speed: 'Ultra Fast',
  },
  {
    id: 'local/client-offline',
    name: 'Local Smart Engine (Zero API / Works Offline)',
    provider: 'Local WebGPU / Offline',
    description: 'Runs entirely in your browser with zero external network requests.',
    badge: 'Zero Network',
    isFreeByDefault: true,
    requiresKey: false,
    speed: 'Ultra Fast',
  },
];

export const SYSTEM_PERSONAS: SystemPersona[] = [
  {
    id: 'general',
    name: 'Universal Assistant',
    icon: 'Sparkles',
    description: 'Balanced, helpful, and friendly AI for any question.',
    systemPrompt: 'You are a highly capable, friendly, and knowledgeable AI assistant designed to provide accurate, clear, and helpful answers.',
  },
  {
    id: 'developer',
    name: 'Code Master & Architect',
    icon: 'Code',
    description: 'Expert software developer, debugger, and code architect.',
    systemPrompt: 'You are an expert senior software engineer and tech architect. Provide clean, efficient, bug-free, well-explained code with best practices.',
  },
  {
    id: 'creative',
    name: 'Creative Writer',
    icon: 'Feather',
    description: 'Storyteller, poet, copywriter, and creative brainstormer.',
    systemPrompt: 'You are an imaginative creative writer and copywriter. Craft vivid, engaging, expressive stories, scripts, and content with rich vocabulary.',
  },
  {
    id: 'tutor',
    name: 'Patient Educator',
    icon: 'GraduationCap',
    description: 'Breaks down complex subjects into simple step-by-step explanations.',
    systemPrompt: 'You are an empathetic, world-class tutor. Explain complex concepts using intuitive analogies, step-by-step breakdowns, and clear examples.',
  },
  {
    id: 'concise',
    name: 'Quick & Direct Q&A',
    icon: 'Zap',
    description: 'Delivers laser-focused answers without extra fluff or filler.',
    systemPrompt: 'You are a direct, concise assistant. Answer questions directly, clearly, and concisely without fluff, preambles, or unneeded disclaimers.',
  },
];

export const QUICK_PROMPTS = [
  {
    title: 'Explain Quantum Computing',
    prompt: 'Explain how quantum computing works using an analogy a 10-year-old would easily understand.',
    icon: 'Atom',
  },
  {
    title: 'Build a Web Scraping Script',
    prompt: 'Write a Python script using BeautifulSoup and Requests to extract news titles from a site cleanly with error handling.',
    icon: 'Code',
  },
  {
    title: 'Design a Product Pitch',
    prompt: 'Help me draft a compelling 1-minute elevator pitch for an AI product that helps small businesses automate email support.',
    icon: 'Lightbulb',
  },
  {
    title: 'Debug & Optimize Code',
    prompt: 'How can I optimize slow React component re-renders? Give 4 practical code techniques.',
    icon: 'Cpu',
  },
];
