export type MessageRole = 'user' | 'assistant' | 'system';

export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: number;
  model?: string;
  error?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
  updatedAt: number;
  systemPersonaId: string;
  modelId: string;
}

export interface AIModel {
  id: string;
  name: string;
  provider: 'OpenRouter Free' | 'Groq' | 'Hugging Face' | 'Local WebGPU / Offline';
  description: string;
  badge: string;
  isFreeByDefault: boolean;
  requiresKey: boolean;
  speed: 'Ultra Fast' | 'Fast' | 'Moderate';
}

export interface SystemPersona {
  id: string;
  name: string;
  icon: string;
  description: string;
  systemPrompt: string;
}

export interface AppSettings {
  activeModelId: string;
  activePersonaId: string;
  openRouterApiKey: string;
  groqApiKey: string;
  huggingFaceApiKey: string;
  temperature: number;
  maxTokens: number;
  autoSpeech: boolean;
}
