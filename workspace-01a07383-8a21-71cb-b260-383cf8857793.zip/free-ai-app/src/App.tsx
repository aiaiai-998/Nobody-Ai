import React, { useState, useEffect, useRef } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { SettingsModal } from './components/SettingsModal';
import { DeployModal } from './components/DeployModal';
import type { Message, ChatSession, AppSettings } from './types';
import { DEFAULT_MODELS, SYSTEM_PERSONAS } from './config/constants';
import { sendChatMessage } from './services/aiService';

const STORAGE_KEY_SESSIONS = 'aura_ai_sessions_v1';
const STORAGE_KEY_SETTINGS = 'aura_ai_settings_v1';

export const App: React.FC = () => {
  // Load initial settings
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return {
      activeModelId: DEFAULT_MODELS[0].id,
      activePersonaId: SYSTEM_PERSONAS[0].id,
      openRouterApiKey: '',
      groqApiKey: '',
      huggingFaceApiKey: '',
      temperature: 0.7,
      maxTokens: 2048,
      autoSpeech: false,
    };
  });

  // Load initial chat sessions
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_SESSIONS);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {}
    }
    // Default welcome chat session
    const defaultSession: ChatSession = {
      id: `session_${Date.now()}`,
      title: 'Welcome to Aura AI',
      messages: [
        {
          id: `msg_welcome`,
          role: 'assistant',
          content: `👋 **Welcome to Aura AI — Your Free Universal AI Assistant!**

I am an open-weight AI chat system designed to be **free for everyone forever**. 

### 🌟 What makes this special:
- **100% Free & Open:** Powered by open-source models like **Qwen 2.5 7B**, **Gemma 2**, and **DeepSeek R1**.
- **Offline / Local Mode:** Switch to **Local Smart Engine** in the top bar to run AI without any API calls or internet dependence.
- **Voice & Speech:** Tap the 🎤 microphone icon to speak your prompts, or tap the 🔊 speaker icon to listen to answers.
- **Deploy It Yourself:** Click **"Deploy For Free"** in the sidebar to host your own copy on Vercel or Netlify in 1 click!

Try asking a question or select a prompt below!`,
          timestamp: Date.now(),
          model: DEFAULT_MODELS[0].name,
        },
      ],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      systemPersonaId: SYSTEM_PERSONAS[0].id,
      modelId: DEFAULT_MODELS[0].id,
    };
    return [defaultSession];
  });

  const [activeSessionId, setActiveSessionId] = useState<string>(() => sessions[0]?.id || '');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isDeployModalOpen, setIsDeployModalOpen] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<boolean>(false);

  // Save settings on update
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
  }, [settings]);

  // Save sessions on update
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_SESSIONS, JSON.stringify(sessions));
  }, [sessions]);

  // Get active session
  const activeSession = sessions.find((s) => s.id === activeSessionId) || sessions[0];

  // Scroll to bottom when messages update
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeSession?.messages, isGenerating]);

  // Update Settings helper
  const handleUpdateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  // Create New Chat Session
  const handleNewChat = () => {
    const newSession: ChatSession = {
      id: `session_${Date.now()}`,
      title: 'New Conversation',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      systemPersonaId: settings.activePersonaId,
      modelId: settings.activeModelId,
    };
    setSessions((prev) => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
  };

  // Delete Chat Session
  const handleDeleteSession = (id: string) => {
    const filtered = sessions.filter((s) => s.id !== id);
    setSessions(filtered);
    if (activeSessionId === id && filtered.length > 0) {
      setActiveSessionId(filtered[0].id);
    } else if (filtered.length === 0) {
      handleNewChat();
    }
  };

  // Select Persona
  const handleSelectPersona = (personaId: string) => {
    handleUpdateSettings({ activePersonaId: personaId });
  };

  // Select Model
  const handleSelectModel = (modelId: string) => {
    handleUpdateSettings({ activeModelId: modelId });
  };

  // Clear current active chat
  const handleClearChat = () => {
    if (!activeSession) return;
    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeSession.id ? { ...s, messages: [], updatedAt: Date.now() } : s
      )
    );
  };

  // Export current active chat
  const handleExportChat = () => {
    if (!activeSession) return;
    const content = activeSession.messages
      .map((m) => `### ${m.role === 'user' ? 'User' : 'AI Assistant'}\n${m.content}\n`)
      .join('\n---\n\n');
    
    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chat-export-${activeSession.title.replace(/\s+/g, '-').toLowerCase()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Handle Send Message
  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isGenerating) return;

    const activeModelObj = DEFAULT_MODELS.find((m) => m.id === settings.activeModelId) || DEFAULT_MODELS[0];
    const activePersonaObj = SYSTEM_PERSONAS.find((p) => p.id === settings.activePersonaId) || SYSTEM_PERSONAS[0];

    const userMessage: Message = {
      id: `msg_${Date.now()}_user`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    const assistantMsgId = `msg_${Date.now()}_assistant`;
    const initialAssistantMessage: Message = {
      id: assistantMsgId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      model: activeModelObj.name,
    };

    // Auto update chat title if this is the first user message
    const isFirstUserMsg = activeSession.messages.filter((m) => m.role === 'user').length === 0;
    const updatedTitle = isFirstUserMsg
      ? text.slice(0, 30) + (text.length > 30 ? '...' : '')
      : activeSession.title;

    // Append messages to current session
    setSessions((prev) =>
      prev.map((s) => {
        if (s.id === activeSession.id) {
          return {
            ...s,
            title: updatedTitle,
            messages: [...s.messages, userMessage, initialAssistantMessage],
            updatedAt: Date.now(),
          };
        }
        return s;
      })
    );

    setIsGenerating(true);
    abortControllerRef.current = false;

    const currentHistory = [...activeSession.messages, userMessage];

    await sendChatMessage(
      currentHistory,
      activePersonaObj.systemPrompt,
      settings,
      {
        onChunk: (chunkText) => {
          if (abortControllerRef.current) return;
          setSessions((prev) =>
            prev.map((s) => {
              if (s.id === activeSession.id) {
                const updatedMsgs = s.messages.map((m) =>
                  m.id === assistantMsgId ? { ...m, content: chunkText } : m
                );
                return { ...s, messages: updatedMsgs };
              }
              return s;
            })
          );
        },
        onFinish: () => {
          setIsGenerating(false);
        },
        onError: (err) => {
          setIsGenerating(false);
          setSessions((prev) =>
            prev.map((s) => {
              if (s.id === activeSession.id) {
                const updatedMsgs = s.messages.map((m) =>
                  m.id === assistantMsgId
                    ? {
                        ...m,
                        content: `⚠️ Request failed: ${err.message}`,
                        error: true,
                      }
                    : m
                );
                return { ...s, messages: updatedMsgs };
              }
              return s;
            })
          );
        },
      }
    );
  };

  const handleStopGeneration = () => {
    abortControllerRef.current = true;
    setIsGenerating(false);
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Sidebar */}
      <Sidebar
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={setActiveSessionId}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
        activePersonaId={settings.activePersonaId}
        onSelectPersona={handleSelectPersona}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenDeployModal={() => setIsDeployModalOpen(true)}
        isOpen={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Content Workspace */}
      <div className="flex-1 flex flex-col h-full min-w-0 bg-slate-950">
        {/* Top Header */}
        <Header
          onToggleMobileSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
          activeModelId={settings.activeModelId}
          onSelectModel={handleSelectModel}
          onClearChat={handleClearChat}
          onExportChat={handleExportChat}
          hasMessages={activeSession?.messages.length > 0}
        />

        {/* Chat Feed */}
        <div className="flex-1 overflow-y-auto scrollbar-thin">
          {activeSession?.messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center p-6 text-center max-w-lg mx-auto">
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-cyan-500 via-blue-500 to-indigo-600 flex items-center justify-center text-white shadow-2xl shadow-cyan-500/30 mb-4 animate-bounce">
                ✨
              </div>
              <h2 className="text-xl font-bold text-slate-100 mb-2">
                What would you like to build or ask?
              </h2>
              <p className="text-sm text-slate-400 leading-relaxed mb-6">
                Your AI assistant is ready. Select a model, choose a prompt below, or type your own question.
              </p>
            </div>
          ) : (
            activeSession?.messages.map((msg, index) => (
              <ChatMessage
                key={msg.id}
                message={msg}
                isLast={index === activeSession.messages.length - 1}
                isStreaming={isGenerating && index === activeSession.messages.length - 1 && msg.role === 'assistant'}
              />
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Bottom Input Area */}
        <ChatInput
          onSendMessage={handleSendMessage}
          onStopGeneration={handleStopGeneration}
          isGenerating={isGenerating}
          isEmptyChat={activeSession?.messages.length === 0}
        />
      </div>

      {/* Modals */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
      />

      <DeployModal
        isOpen={isDeployModalOpen}
        onClose={() => setIsDeployModalOpen(false)}
      />
    </div>
  );
};

export default App;
