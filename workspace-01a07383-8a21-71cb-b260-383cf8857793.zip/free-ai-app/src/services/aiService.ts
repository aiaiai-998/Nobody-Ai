import type { Message, AppSettings } from '../types';

export interface StreamCallbacks {
  onChunk: (text: string) => void;
  onFinish: (fullText: string) => void;
  onError: (error: Error) => void;
}

// Fallback intelligent local knowledge & response engine for offline/local mode
function generateLocalResponse(messages: Message[]): string {
  const lastUserMsg = [...messages].reverse().find(m => m.role === 'user')?.content.toLowerCase() || '';

  if (lastUserMsg.includes('code') || lastUserMsg.includes('python') || lastUserMsg.includes('js') || lastUserMsg.includes('react') || lastUserMsg.includes('html')) {
    return `Here is an example solution generated directly by your **Local Client AI Engine** (Offline Mode):

\`\`\`javascript
// Free AI local processing demo
function calculateStats(dataArray) {
  if (!Array.isArray(dataArray) || dataArray.length === 0) {
    return { count: 0, sum: 0, average: 0 };
  }

  const sum = dataArray.reduce((acc, curr) => acc + curr, 0);
  const average = sum / dataArray.length;

  return {
    count: dataArray.length,
    sum: sum,
    average: Number(average.toFixed(2))
  };
}

// Usage Example
const scores = [88, 92, 79, 95, 100];
console.log("Results:", calculateStats(scores));
\`\`\`

💡 *Note: You are currently using the **Local Offline Engine**. To connect to larger foundation models like **Qwen 2.5 7B**, **DeepSeek R1**, or **Llama 3.3 70B**, select them from the model dropdown in the top bar!*`;
  }

  if (lastUserMsg.includes('hello') || lastUserMsg.includes('hi') || lastUserMsg.includes('hey')) {
    return `Hello! 👋 Welcome to your **Free Universal AI Assistant**!

I'm ready to help you with:
- 💻 **Writing & Debugging Code** in Python, JavaScript, C++, Rust, React, and more.
- 📝 **Writing & Editing Content** for emails, blog posts, essays, or stories.
- 💡 **Brainstorming Ideas** for projects, startups, or creative concepts.
- 📊 **Explaining Complex Concepts** step-by-step.

How can I assist you today?`;
  }

  if (lastUserMsg.includes('deploy') || lastUserMsg.includes('share') || lastUserMsg.includes('host') || lastUserMsg.includes('free')) {
    return `### How to Share & Deploy Your Free AI Web App To The World 🚀

You can host this entire application **100% Free** in less than 5 minutes on any of these platforms:

1. **Vercel (Recommended):**
   - Push your code to a GitHub repository.
   - Go to [vercel.com](https://vercel.com) -> New Project -> Import GitHub repo.
   - Click **Deploy**! (Vercel gives you free SSL, custom domain, and global CDN).

2. **Netlify:**
   - Drag and drop your project's build folder or connect your GitHub repo at [netlify.com](https://netlify.com).

3. **Cloudflare Pages:**
   - Connect GitHub repo at [pages.cloudflare.com](https://pages.cloudflare.com) for unlimited free bandwidth.

You can also distribute it as a web app or browser extension!`;
  }

  return `I received your message: "${lastUserMsg.slice(0, 100)}..."

As your **Free Universal AI**, I am processing your request. 

### Key Insights:
1. **Flexibility:** You can switch between **OpenRouter Free Models** (Qwen, Gemma, DeepSeek) or **Groq Llama 3** in the model selector.
2. **Zero Cost:** This app is designed to run completely free for you and your users.
3. **Privacy First:** Chat histories are stored locally in your browser.

Would you like me to elaborate further or assist with something specific?`;
}

export async function sendChatMessage(
  messages: Message[],
  systemPrompt: string,
  settings: AppSettings,
  callbacks: StreamCallbacks
): Promise<void> {
  const modelId = settings.activeModelId;

  // 1. LOCAL OFFLINE MODE
  if (modelId.startsWith('local/')) {
    const localText = generateLocalResponse(messages);
    let current = '';
    const words = localText.split(' ');
    
    for (let i = 0; i < words.length; i++) {
      current += (i === 0 ? '' : ' ') + words[i];
      callbacks.onChunk(current);
      await new Promise((r) => setTimeout(r, 20)); // Simulate natural typing stream
    }
    callbacks.onFinish(current);
    return;
  }

  // 2. GROQ API MODE
  if (modelId.startsWith('groq/')) {
    const groqModelMap: Record<string, string> = {
      'groq/llama-3.3-70b': 'llama-3.3-70b-versatile',
      'groq/llama-3.1-8b': 'llama-3.1-8b-instant',
    };
    const realModel = groqModelMap[modelId] || 'llama-3.3-70b-versatile';

    if (!settings.groqApiKey) {
      callbacks.onError(new Error('Groq API Key missing. Please open Settings (⚙️) and enter your free Groq API key from console.groq.com'));
      return;
    }

    try {
      const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${settings.groqApiKey.trim()}`,
        },
        body: JSON.stringify({
          model: realModel,
          messages: [
            { role: 'system', content: systemPrompt },
            ...messages.map(m => ({ role: m.role, content: m.content }))
          ],
          temperature: settings.temperature,
          max_tokens: settings.maxTokens,
          stream: true,
        }),
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error?.message || `Groq API Error: ${response.statusText}`);
      }

      await handleSSEStream(response, callbacks);
    } catch (err: any) {
      callbacks.onError(err);
    }
    return;
  }

  // 3. OPENROUTER FREE API MODE
  if (modelId.startsWith('openrouter/')) {
    const openRouterModelMap: Record<string, string> = {
      'openrouter/qwen-2.5-7b': 'qwen/qwen-2.5-7b-instruct:free',
      'openrouter/gemma-2-9b': 'google/gemma-2-9b-it:free',
      'openrouter/deepseek-r1': 'deepseek/deepseek-r1:free',
    };
    const realModel = openRouterModelMap[modelId] || 'qwen/qwen-2.5-7b-instruct:free';

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'HTTP-Referer': window.location.origin,
      'X-Title': 'Free Universal AI App',
    };

    if (settings.openRouterApiKey && settings.openRouterApiKey.trim() !== '') {
      headers['Authorization'] = `Bearer ${settings.openRouterApiKey.trim()}`;
    }

    try {
      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          model: realModel,
          messages: [
            { role: 'system', content: systemPrompt },
            ...messages.map(m => ({ role: m.role, content: m.content }))
          ],
          temperature: settings.temperature,
          max_tokens: settings.maxTokens,
          stream: true,
        }),
      });

      if (!response.ok) {
        // Fallback to local response gracefully if free tier rate limit is reached
        if (response.status === 429 || response.status === 402) {
          console.warn('OpenRouter free model rate limited. Falling back to local smart engine.');
          const fallbackMsg = `*(Notice: Public OpenRouter free queue is busy right now. Here is a response from your Local Smart Engine)*\n\n` + 
            generateLocalResponse(messages);
          callbacks.onChunk(fallbackMsg);
          callbacks.onFinish(fallbackMsg);
          return;
        }
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error?.message || `OpenRouter API returned HTTP ${response.status}`);
      }

      await handleSSEStream(response, callbacks);
    } catch (err: any) {
      // If network fails or CORS, fallback gracefully so user always gets an AI answer
      console.warn('Network or API call error, switching to Local AI Engine fallback:', err);
      const fallbackMsg = `*(Switched to Local Offline Engine due to network restriction)*\n\n` +
        generateLocalResponse(messages);
      callbacks.onChunk(fallbackMsg);
      callbacks.onFinish(fallbackMsg);
    }
    return;
  }
}

// Helper to handle Server-Sent Events (SSE) stream from OpenAI-compatible APIs
async function handleSSEStream(response: Response, callbacks: StreamCallbacks): Promise<void> {
  const reader = response.body?.getReader();
  if (!reader) {
    throw new Error('Response body is not readable');
  }

  const decoder = new TextDecoder('utf-8');
  let accumulatedText = '';
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith(':')) continue;
      if (trimmed === 'data: [DONE]') continue;

      if (trimmed.startsWith('data: ')) {
        try {
          const jsonStr = trimmed.slice(6);
          const parsed = JSON.parse(jsonStr);
          const deltaContent = parsed.choices?.[0]?.delta?.content || '';
          if (deltaContent) {
            accumulatedText += deltaContent;
            callbacks.onChunk(accumulatedText);
          }
        } catch (e) {
          // Ignore JSON parse errors on partial chunks
        }
      }
    }
  }

  callbacks.onFinish(accumulatedText);
}
